-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2018 at 08:14 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db`
--

-- --------------------------------------------------------

--
-- Table structure for table `comentarios`
--

CREATE TABLE IF NOT EXISTS `comentarios` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(30) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mensaje` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `comentarios`
--

INSERT INTO `comentarios` (`id`, `usuario`, `fecha`, `mensaje`) VALUES
(1, 'hola', '2018-05-22 20:35:28', 'mundo'),
(2, 'hola', '2018-05-22 20:35:47', 'mundo'),
(3, 'hola', '2018-05-22 20:36:12', 'mundo'),
(4, 'hola', '2018-05-22 20:36:59', 'mundo'),
(5, 'hola', '2018-05-22 20:37:14', 'mundo'),
(6, 'hola', '2018-05-22 20:37:36', 'mundo'),
(7, '', '2018-05-22 21:14:28', 'mundo'),
(8, '', '2018-05-22 21:15:53', 'mundo'),
(9, '', '2018-05-22 21:16:19', 'mundo'),
(10, '', '2018-05-22 22:12:50', ' sadsad'),
(11, 'Jesus', '2018-05-22 22:16:54', ' sadsadas'),
(12, 'Jesus', '2018-05-22 22:16:56', ' sadsadsad'),
(13, 'Juan', '2018-05-23 00:11:36', ''),
(14, 'Juan', '2018-05-23 00:20:30', ''),
(15, 'Juan', '2018-05-23 00:20:54', ''),
(16, 'Juan', '2018-05-23 00:32:21', ''),
(17, 'Juan', '2018-05-23 00:32:52', ''),
(18, 'Juan', '2018-05-23 00:33:18', ''),
(19, 'Juan', '2018-05-23 00:33:24', ''),
(20, 'Juan', '2018-05-23 00:33:43', ''),
(21, 'Juan', '2018-05-23 00:33:50', ''),
(22, 'Juan', '2018-05-23 00:33:54', ''),
(23, 'Juan', '2018-05-23 00:53:51', ''),
(24, 'Juan', '2018-05-23 00:53:57', ''),
(25, 'Juan', '2018-05-23 12:28:34', ''),
(26, 'Juan716', '2018-05-23 20:47:30', ' hey falta un electrodomestico no, estoy mostrandole a mi hermano xD ahh ');

-- --------------------------------------------------------

--
-- Table structure for table `costo`
--

CREATE TABLE IF NOT EXISTS `costo` (
  `valor` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `electrodomesticos`
--

CREATE TABLE IF NOT EXISTS `electrodomesticos` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `potencia` bigint(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `electrodomesticos`
--

INSERT INTO `electrodomesticos` (`id`, `nombre`, `potencia`) VALUES
(1, 'Enfriador', 500);

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `apellidos` varchar(80) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `clave` varchar(20) NOT NULL,
  `telefono` bigint(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`id`, `nombre`, `apellidos`, `correo`, `usuario`, `clave`, `telefono`) VALUES
(1, 'Juan', 'Bojato', 'jbojato@uninorte.edu.co', 'Juan', '123', 3016698196),
(2, 'Jesus David', 'Santiago Jarava', 'jesusdavid2607@gmail.com', 'jesu2607', '260700', 3183519851),
(5, 'Juan', 'Bojato', 'juandavidcancer@hotmail.com', 'Juan716', '123', 3016698196);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
