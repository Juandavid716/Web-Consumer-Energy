<?php
if($_POST['1']){
    header("location:admin.php");
} else if($_POST['2']) {
    header("location:cerrarsesion.php");
    
}

?>